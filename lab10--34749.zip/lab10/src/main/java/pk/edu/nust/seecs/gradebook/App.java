package pk.edu.nust.seecs.gradebook;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

//essential imports to implement functions
import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.dao.ContentDao;
import pk.edu.nust.seecs.gradebook.dao.CourseDao;
import pk.edu.nust.seecs.gradebook.dao.GradeDao;
import pk.edu.nust.seecs.gradebook.dao.StudentDao;
import pk.edu.nust.seecs.gradebook.dao.TeacherDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;
import pk.edu.nust.seecs.gradebook.entity.Content;
import pk.edu.nust.seecs.gradebook.entity.Grade;


/**
 * My main App. 
 * <p>
 This executes everything.
 */

public class App {

    public static void main(String[] args) {
        //function declerations
        CloDao clodao = new CloDao();
        ContentDao contentdao = new ContentDao();
        CourseDao coursedao = new CourseDao();
        GradeDao gradedao = new GradeDao();
        StudentDao studentdao = new StudentDao();
        TeacherDao teacherdao = new TeacherDao();
    }
    /**
     *
     * @param clodao
     */
    //add clo function allows user to enter details regarding clos
    static void addCLO(CloDao clodao){
        Scanner reader = new Scanner(System.in);
       
     
       
        //clodao.addClo(clo);
    }
    
    //update clo function allows user to enter details regarding clos
    static void updateCLO(CloDao clodao){
        Scanner reader = new Scanner(System.in);
        
        
       
        //clodao.updateClo(clo);
    }

    //add grade function allows user to enter details regarding grades
    static void addGrade(GradeDao gradedao, ContentDao contentdao){
        Scanner reader = new Scanner(System.in);
        Grade grade = new Grade();
        
        System.out.print("Name: ");
        grade.setName(reader.next());
        
        System.out.print("Score: ");
        grade.setScore(reader.nextInt());
        
        System.out.print("Content ID: ");
        grade.setContentItem(contentdao.getContentById(reader.nextInt()));
        
        gradedao.addGrade(grade);
    }
    
    //update grade function allows user to enter details regarding grades
    static void updateGrade(GradeDao gradedao, ContentDao contentdao){
        Scanner reader = new Scanner(System.in);
        Grade grade = new Grade();
        
        System.out.print("Name: ");
        grade.setName(reader.next());
        
        System.out.print("Score: ");
        grade.setScore(reader.nextInt());
        
        System.out.print("Content ID: ");
        grade.setContentItem(contentdao.getContentById(reader.nextInt()));
        
        gradedao.addGrade(grade);
    } 
    //add content function allows user to enter details regarding contents
    static void addContent(ContentDao contentdao, CourseDao coursedao) throws ParseException{
        Scanner reader = new Scanner(System.in);
        DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        Content content = new Content();
        
        System.out.print("Title: ");
        content.setTitle(reader.next());
        
        System.out.print("Description: ");
        content.setDescription(reader.next());
        
        System.out.print("Start Date: ");
        content.setStarttime(df.parse(reader.next()));
        
        System.out.print("End Date: ");
        content.setEndtime(df.parse(reader.next()));
        
        System.out.print("Course ID: ");
        content.setCourse(coursedao.getCourseById(reader.nextInt()));
        
        contentdao.addContent(content);
    }
    
    //update content function allows user to enter details regarding content
    static void updateContent(ContentDao contentdao, CourseDao coursedao) throws ParseException{
        Scanner reader = new Scanner(System.in);
        DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        Content content = new Content();
        
        System.out.print("Title: ");
        content.setTitle(reader.next());
        
        System.out.print("Description: ");
        content.setDescription(reader.next());
        
        System.out.print("Start Date (dd-mm-yyyy): ");
        content.setStarttime(df.parse(reader.next()));
        
        System.out.print("End Date (dd-mm-yyyy): ");
        content.setEndtime(df.parse(reader.next()));
        
        System.out.print("Course ID: ");
        content.setCourse(coursedao.getCourseById(reader.nextInt()));
        
        contentdao.updateContent(content);
    } 
    static void displayContents(ContentDao contentdao, GradeDao gradedao){
        List<Content> contents = contentdao.getAllContents();
        List<Grade> grades = gradedao.getAllGrades();
        
        for (Content iter: contents){
            for (Grade g: grades){
                if (iter.getContentId() == g.getContentItem().getContentId()){
                    System.out.println(iter);
                    break;
                }
            }
        }
    }
}
